import { Conversation, KeyValuePair, Message, OpenAIModel } from '../../../../models/chatweb3/chatweb3';
import { Dispatch, FC, MutableRefObject, SetStateAction, useEffect, useRef, useState } from 'react';
import { ChatInput } from './ChatInput';
import { ChatLoader } from './ChatLoader';
import { ChatMessage } from './ChatMessage';
import { Regenerate } from './Regenerate';
import React from 'react';
import '../../styles/chatweb3.css';
import { Navbar } from './ChatWeb3Navbar';
import { CompletedSuccessfulSimulation } from '../../../../lib/simulation/storage';

interface Props {
  conversation: Conversation;
  models: OpenAIModel[];
  messageIsStreaming: boolean;
  modelError: boolean;
  messageError: boolean;
  loading: boolean;
  lightMode: 'dark';
  onSend: (message: Message, isResend: boolean, storedSimulation?: CompletedSuccessfulSimulation) => void;
  onUpdateConversation: (conversation: Conversation, data: KeyValuePair) => void;
  stopConversationRef: MutableRefObject<boolean>;
  showChatWeb3?: boolean;
  setShowChatWeb3?: Dispatch<SetStateAction<boolean>> | undefined;
  storedSimulation?: CompletedSuccessfulSimulation;
}

export const Chat: FC<Props> = ({
  conversation,
  messageIsStreaming,
  messageError,
  loading,
  lightMode,
  onSend,
  onUpdateConversation,
  stopConversationRef,
  showChatWeb3,
  setShowChatWeb3,
  storedSimulation,
}) => {
  const [currentMessage, setCurrentMessage] = useState<Message>();

  const [hideOnLargeScreens, setHideOnLargeScreens] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setHideOnLargeScreens(window.matchMedia('(min-width: 600px)').matches);
    };

    // Add event listener to update the state on resize
    window.addEventListener('resize', handleResize);

    // Initial check on component mount
    handleResize();

    // Clean up the event listener on component unmount
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'auto' });
  };

  useEffect(() => {
    scrollToBottom();
    textareaRef.current?.focus();
  }, [conversation.messages]);

  return (
    <div
      style={{
        flex: 1,
      }}
    >
      {/* only show this navbar when there is no simulation. if this is true, the source of the request was the hotkey */}
      {!storedSimulation && (
        <Navbar showChatWeb3={showChatWeb3} setShowChatWeb3={setShowChatWeb3} />
      )}
      {conversation?.messages.length === 0 ? (
        <>
          <div style={{ height: '162px' }} ref={messagesEndRef} />
        </>
      ) : (
        <>
          {conversation?.messages &&
            conversation?.messages.map((message, index) => <ChatMessage key={index} message={message} index={index} source={storedSimulation ? 'simulation' : 'hotkey'} />)}

          {loading && <ChatLoader />}

          <div style={{ height: '184px' }} ref={messagesEndRef} />
        </>
      )}
      <>
        {messageError ? (
          <Regenerate
            onRegenerate={() => {
              if (currentMessage) {
                onSend(currentMessage, true);
              }
            }}
          />
        ) : (
          <ChatInput
            stopConversationRef={stopConversationRef}
            storedSimulation={storedSimulation}
            messageIsStreaming={messageIsStreaming}
            textareaRef={textareaRef}
            showChatWeb3={showChatWeb3}
            onSend={(message) => {
              setCurrentMessage(message);
              if (storedSimulation) {
                onSend(message, false, storedSimulation);
              } else {
                onSend(message, false);
              }
            }}
            model={conversation.model}
          />
        )}
      </>
    </div>
  );
};
