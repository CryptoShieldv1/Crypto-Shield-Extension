module.exports = {
  roots: ['src'],
  transform: {
    '^.+\\.ts$': 'ts-jest',
  },
};
